// Get elements
const list = document.getElementById('photo-list');
const details = document.getElementById('photo-details');

// Load photo titles
fetch('/photos')
  .then(res => res.json())
  .then(data => {
    data.forEach(photo => {
      const li = document.createElement('li');
      li.textContent = photo.title;
      li.style.cursor = 'pointer';
      li.addEventListener('click', () => showPhoto(photo.id));
      list.appendChild(li);
    });
  })
  .catch(err => {
    list.innerHTML = `<li>Error loading photos: ${err.message}</li>`;
  });

// Show full photo info
function showPhoto(id) {
  fetch(`/photos/${id}`)
    .then(res => res.json())
    .then(photo => {
      details.innerHTML = `
        <h2>${photo.title}</h2>
        <p><strong>Album ID:</strong> ${photo.albumId}</p>
        <p><strong>ID:</strong> ${photo.id}</p>
        <p><strong>URL:</strong> ${photo.url}</p>
        <p><strong>Thumbnail:</strong> ${photo.thumbnailUrl}</p>
      `;
    })
    .catch(err => {
      details.innerHTML = `<p>Error loading photo: ${err.message}</p>`;
    });
}
