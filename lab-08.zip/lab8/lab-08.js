const express = require('express');
const path = require('path');

const app = express();
app.use(express.static(path.join(process.cwd(), 'public')));

const PORT = 8080;
const HOST = 'localhost';

// #3: TODO:
// Serve static files from public subfolder using .use(), express.static(), and path.join().
// Rather than __dirname, use process.cwd()

app.get("/photos", (request, response) => {
  fetch('https://jsonplaceholder.typicode.com/photos')
    .then((res) => res.json())
    .then((json) => 
      response.status(200).type("application/json").send(json.slice(0,20)))
    
    .catch((err) => 
      response
      .status(500)
      .type("application/json")
      .send({error: `${err}`}));

  });


app.get("/photos/:id", (request, response) => {
  const id = request.params.id;
  
  fetch(`https://jsonplaceholder.typicode.com/photos/${id}`)
    .then(res => res.json())
    .then(photo => {
      response.status(200).json(photo);
    })
    .catch(err => {
      response.status(500).json({ error: `${err}` });
    });
  });
  

// Handle 404 for unknown routes
app.use((request, response) => {
  response.status(404).json({ error: 'Route not found' });
});

// Start server
app.listen(PORT, HOST, () => {
  console.log('Working directory:', process.cwd());
  console.log(`Server running at http://${HOST}:${PORT}`);
});